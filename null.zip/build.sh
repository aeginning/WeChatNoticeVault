#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.13 is required. Install it or open this project with Android Studio."
  exit 2
fi
gradle --version
gradle :app:clean :app:testDebugUnitTest :app:assembleDebug
