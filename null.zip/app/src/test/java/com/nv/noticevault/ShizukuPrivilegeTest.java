package com.nv.noticevault;

import org.junit.Test;
import static org.junit.Assert.*;

public class ShizukuPrivilegeTest {
    @Test public void disconnectedWhenBinderIsUnavailable() {
        assertEquals(ShizukuPrivilege.Mode.DISCONNECTED,
                ShizukuPrivilege.classify(false, 2000));
    }

    @Test public void identifiesWirelessDebuggingAdbShell() {
        assertEquals(ShizukuPrivilege.Mode.ADB_SHELL,
                ShizukuPrivilege.classify(true, 2000));
    }

    @Test public void identifiesRootSeparately() {
        assertEquals(ShizukuPrivilege.Mode.ROOT,
                ShizukuPrivilege.classify(true, 0));
    }

    @Test public void doesNotAssumeUnknownUidIsAdb() {
        assertEquals(ShizukuPrivilege.Mode.OTHER,
                ShizukuPrivilege.classify(true, 10123));
    }
}
