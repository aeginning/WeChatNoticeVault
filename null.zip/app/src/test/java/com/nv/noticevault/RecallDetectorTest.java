package com.nv.noticevault;

import org.junit.Test;
import static org.junit.Assert.*;

public class RecallDetectorTest {
    @Test public void detectsExplicitChineseRecallNotice() {
        assertTrue(RecallDetector.isExplicitRecallNotice("张三撤回了一条消息"));
        assertTrue(RecallDetector.isExplicitRecallNotice("你撤回了一条信息"));
    }

    @Test public void detectsExplicitEnglishRecallNotice() {
        assertTrue(RecallDetector.isExplicitRecallNotice("Someone recalled a message"));
        assertTrue(RecallDetector.isExplicitRecallNotice("A message was recalled"));
    }

    @Test public void doesNotTreatOrdinaryRemovalOrDiscussionAsRecall() {
        assertFalse(RecallDetector.isExplicitRecallNotice("通知已移除"));
        assertFalse(RecallDetector.isExplicitRecallNotice("刚才撤回的话题我们继续讨论"));
        assertFalse(RecallDetector.isExplicitRecallNotice("普通聊天内容"));
    }
}
