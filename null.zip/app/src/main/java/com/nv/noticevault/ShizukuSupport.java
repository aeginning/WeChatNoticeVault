package com.nv.noticevault;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.TextUtils;

import rikka.shizuku.Shizuku;

/** Read-only Shizuku and Android system diagnostics. Never runs arbitrary shell commands. */
public final class ShizukuSupport {
    public static final int REQUEST_CODE = 2181;
    private static final String SHIZUKU_PACKAGE = "moe.shizuku.privileged.api";

    private ShizukuSupport() { }

    public static boolean isConnected() {
        try { return Shizuku.pingBinder(); }
        catch (Throwable ignored) { return false; }
    }

    public static boolean isInstalled(Context context) {
        try {
            context.getPackageManager().getPackageInfo(SHIZUKU_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException | RuntimeException e) {
            return false;
        }
    }

    public static int getServerUid() {
        if (!isConnected()) return -1;
        try { return Shizuku.getUid(); }
        catch (Throwable ignored) { return -1; }
    }

    public static boolean hasAppPermission() {
        if (!isConnected()) return false;
        try { return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable ignored) { return false; }
    }

    public static boolean hasRemoteDumpPermission() {
        if (!isConnected()) return false;
        try { return Shizuku.checkRemotePermission("android.permission.DUMP") == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable ignored) { return false; }
    }

    public static int getServerVersion() {
        if (!isConnected()) return -1;
        try { return Shizuku.getVersion(); }
        catch (Throwable ignored) { return -1; }
    }

    public static boolean hasNotificationAccess(Context context) {
        String enabled = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        if (TextUtils.isEmpty(enabled)) return false;
        String expected = context.getPackageName() + "/" + WeChatNotificationListener.class.getName();
        for (String component : enabled.split(":")) {
            if (expected.equalsIgnoreCase(component)) return true;
        }
        return false;
    }

    public static boolean ignoresBatteryOptimizations(Context context) {
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(context.getPackageName());
    }

    public static boolean isPowerSaveMode(Context context) {
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isPowerSaveMode();
    }

    public static String buildReport(Context context) {
        StringBuilder out = new StringBuilder();
        boolean connected = isConnected();
        int uid = connected ? getServerUid() : -1;
        ShizukuPrivilege.Mode mode = ShizukuPrivilege.classify(connected, uid);
        out.append("Shizuku：").append(connected ? "已连接" : (isInstalled(context) ? "未运行 / 未连接" : "未安装")).append('\n');
        if (connected) {
            out.append("服务 UID：").append(uid).append("（");
            switch (mode) {
                case ADB_SHELL: out.append("ADB Shell，无 Root"); break;
                case ROOT: out.append("Root"); break;
                case OTHER: out.append("未知身份"); break;
                default: out.append("未连接"); break;
            }
            out.append("）\n");
            out.append("Shizuku API：").append(getServerVersion()).append("\n");
            String seContext;
            try { seContext = Shizuku.getSELinuxContext(); }
            catch (Throwable ignored) { seContext = null; }
            out.append("SELinux 上下文：").append(seContext == null ? "不可读取" : seContext).append('\n');
            out.append("本应用 Shizuku 授权：").append(hasAppPermission() ? "已授权" : "未授权").append('\n');
            out.append("远端 DUMP 权限：").append(hasRemoteDumpPermission() ? "可用" : "不可用").append('\n');
        } else {
            out.append("启动 Shizuku 后返回此页刷新状态。无线调试模式重启手机后通常需要重新启动 Shizuku。\n");
        }
        out.append("\nAndroid：").append(android.os.Build.VERSION.RELEASE).append(" / API ").append(android.os.Build.VERSION.SDK_INT).append('\n');
        out.append("设备：").append(android.os.Build.MANUFACTURER).append(' ').append(android.os.Build.MODEL).append('\n');
        out.append("微信通知使用权：").append(hasNotificationAccess(context) ? "已开启" : "未开启（需在系统设置手动授权）").append('\n');
        out.append("电池优化：").append(ignoresBatteryOptimizations(context) ? "已忽略应用电池优化" : "仍受电池优化管理").append('\n');
        out.append("系统省电模式：").append(isPowerSaveMode(context) ? "开启" : "关闭").append('\n');
        if (android.os.Build.MANUFACTURER != null && android.os.Build.MANUFACTURER.toLowerCase(java.util.Locale.ROOT).contains("xiaomi")) {
            out.append("小米后台提示：可在系统设置中检查自启动、后台弹出界面及省电策略；不同 MIUI / HyperOS 版本入口可能不同。\n");
        }
        out.append("\n说明：诊断只读取系统公开状态与 Shizuku 权限状态，不修改微信，不读取微信私有目录，也不会自动授予通知使用权。");
        return out.toString();
    }
}
