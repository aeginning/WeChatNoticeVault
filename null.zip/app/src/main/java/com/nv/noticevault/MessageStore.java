package com.nv.noticevault;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Encrypted local archive. The SQLite payload columns contain only AES-GCM ciphertext. */
public final class MessageStore extends SQLiteOpenHelper {
    private static final String TAG = "NVProStore";
    private static final String DB_NAME = "notice_archive.db"; // Keep v1 filename for in-place migration.
    private static final int DB_VERSION = 2;
    public static final int MAX_ROWS = 10_000;
    private static final int MAX_ATTACHMENT_BYTES = 5 * 1024 * 1024;

    private final Context appContext;
    private final CryptoManager crypto;
    private final File attachmentDir;

    public MessageStore(Context context) {
        super(context.getApplicationContext(), DB_NAME, null, DB_VERSION);
        appContext = context.getApplicationContext();
        crypto = new CryptoManager();
        attachmentDir = new File(appContext.getFilesDir(), "attachments");
        try {
            crypto.ensureKey();
            if (!attachmentDir.exists() && !attachmentDir.mkdirs()) {
                throw new IllegalStateException("无法创建附件目录");
            }
        } catch (Exception e) {
            throw new IllegalStateException("本机加密密钥初始化失败", e);
        }
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        // Reduce the chance that deleted v1 plaintext remnants remain in freed SQLite pages.
        db.execSQL("PRAGMA secure_delete=ON");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createEncryptedTable(db);
    }

    private void createEncryptedTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS records (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nonce BLOB NOT NULL," +
                "payload BLOB NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            createEncryptedTable(db);
            if (tableExists(db, "messages")) {
                Cursor c = db.rawQuery("SELECT _id, posted_at, conversation, sender, content, package_name FROM messages ORDER BY _id ASC", null);
                try {
                    while (c.moveToNext()) {
                        ArchivedMessage m = new ArchivedMessage();
                        m.id = c.getLong(0);
                        m.postedAt = c.getLong(1);
                        m.notificationPostedAt = m.postedAt;
                        m.conversation = safe(c.getString(2), "未命名会话");
                        m.sender = safe(c.getString(3), "");
                        m.content = safe(c.getString(4), "");
                        m.recordType = "MESSAGE";
                        m.messageType = "text";
                        try {
                            CryptoManager.EncryptedBlob blob = crypto.encryptLocal(
                                    m.toJson().toString().getBytes(StandardCharsets.UTF_8), recordAad(m.id));
                            ContentValues values = new ContentValues();
                            values.put("_id", m.id);
                            values.put("nonce", blob.iv);
                            values.put("payload", blob.ciphertext);
                            db.insertOrThrow("records", null, values);
                        } catch (Exception e) {
                            throw new IllegalStateException("迁移旧版消息失败，已中止数据库升级", e);
                        }
                    }
                } finally {
                    c.close();
                }
                db.execSQL("DROP TABLE messages");
            }
        }
    }

    private static boolean tableExists(SQLiteDatabase db, String table) {
        Cursor c = db.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", new String[]{table});
        try { return c.moveToFirst(); }
        finally { c.close(); }
    }

    /** Save an incoming message. Returns the inserted or matching existing row id. */
    public synchronized long add(ArchivedMessage message) {
        if (message == null || (message.content.trim().isEmpty() && message.attachmentPath.trim().isEmpty())) return 0;
        SQLiteDatabase db = getWritableDatabase();
        List<ArchivedMessage> recent = getLatestInternal(db, 160);
        long stamp = message.postedAt > 0 ? message.postedAt : System.currentTimeMillis();
        message.postedAt = stamp;
        for (ArchivedMessage old : recent) {
            if (!message.notificationKey.isEmpty() && message.notificationKey.equals(old.notificationKey)
                    && message.conversation.equals(old.conversation)
                    && message.sender.equals(old.sender)
                    && message.content.equals(old.content)
                    && Math.abs(message.postedAt - old.postedAt) <= 8_000L) {
                if (!message.attachmentPath.isEmpty()) {
                    if (old.attachmentPath.isEmpty()) {
                        old.attachmentPath = message.attachmentPath;
                        old.attachmentMime = message.attachmentMime;
                        old.attachmentName = message.attachmentName;
                        try { updateEncrypted(db, old); }
                        catch (Exception e) { Log.e(TAG, "Failed to attach duplicate preview", e); }
                    } else if (!old.attachmentPath.equals(message.attachmentPath)) {
                        deleteAttachmentFile(message.attachmentPath);
                    }
                }
                return old.id;
            }
        }

        if ("RECALL_EVENT".equals(message.recordType) && message.linkedMessageId == 0) {
            ArchivedMessage candidate = findRecallCandidate(recent, message);
            if (candidate != null) message.linkedMessageId = candidate.id;
        }

        try {
            long id = insertEncryptedRow(db, message);
            if (id <= 0) {
                deleteAttachmentFile(message.attachmentPath);
                return 0;
            }
            trimOldRows(db);
            return id;
        } catch (Exception e) {
            deleteAttachmentFile(message.attachmentPath);
            Log.e(TAG, "Cannot encrypt/store message", e);
            return 0;
        }
    }

    private long insertEncryptedRow(SQLiteDatabase db, ArchivedMessage message) throws Exception {
        // Allocate a row id first; it is authenticated as AES-GCM associated data.
        db.beginTransaction();
        try {
            ContentValues placeholder = new ContentValues();
            placeholder.put("nonce", new byte[12]);
            placeholder.put("payload", new byte[16]);
            long id = db.insert("records", null, placeholder);
            if (id <= 0) return 0;
            message.id = id;
            updateEncrypted(db, message);
            db.setTransactionSuccessful();
            return id;
        } finally {
            db.endTransaction();
        }
    }

    private static String duplicateSignature(ArchivedMessage m) {
        if (m.notificationKey == null || m.notificationKey.isEmpty()) return null;
        StringBuilder b = new StringBuilder();
        appendToken(b, m.notificationKey);
        appendToken(b, String.valueOf(m.postedAt));
        appendToken(b, safe(m.conversation, ""));
        appendToken(b, safe(m.sender, ""));
        appendToken(b, safe(m.content, ""));
        return b.toString();
    }

    private static void appendToken(StringBuilder builder, String value) {
        String s = value == null ? "" : value;
        builder.append(s.length()).append(':').append(s);
    }

    private ArchivedMessage findRecallCandidate(List<ArchivedMessage> rows, ArchivedMessage recall) {
        ArchivedMessage best = null;
        long bestDelta = Long.MAX_VALUE;
        for (ArchivedMessage old : rows) {
            if (!"MESSAGE".equals(old.recordType)) continue;
            if (!old.conversation.equals(recall.conversation)) continue;
            long delta = recall.postedAt - old.postedAt;
            if (delta < 0 || delta > 15 * 60 * 1000L) continue;
            if (!recall.sender.isEmpty() && !old.sender.isEmpty() && !recall.sender.equals(old.sender)) continue;
            if (delta < bestDelta) {
                best = old;
                bestDelta = delta;
            }
        }
        return best;
    }

    private void trimOldRows(SQLiteDatabase db) {
        Cursor c = db.rawQuery("SELECT COUNT(*) FROM records", null);
        int count;
        try { count = c.moveToFirst() ? c.getInt(0) : 0; }
        finally { c.close(); }
        if (count <= MAX_ROWS) return;
        List<ArchivedMessage> all = getAllInternal(db);
        all.sort(Comparator.comparingLong(m -> m.postedAt));
        int remove = count - MAX_ROWS;
        for (int i = 0; i < remove && i < all.size(); i++) {
            ArchivedMessage m = all.get(i);
            db.delete("records", "_id=?", new String[]{String.valueOf(m.id)});
            deleteAttachmentFile(m.attachmentPath);
        }
    }

    private List<ArchivedMessage> getLatestInternal(SQLiteDatabase db, int limit) {
        ArrayList<ArchivedMessage> result = new ArrayList<>();
        Cursor c = db.rawQuery("SELECT _id, nonce, payload FROM records ORDER BY _id DESC LIMIT ?", new String[]{String.valueOf(limit)});
        try {
            while (c.moveToNext()) {
                ArchivedMessage m = decode(c.getLong(0), c.getBlob(1), c.getBlob(2));
                if (m != null) result.add(m);
            }
        } finally { c.close(); }
        return result;
    }

    private List<ArchivedMessage> getAllInternal(SQLiteDatabase db) {
        ArrayList<ArchivedMessage> result = new ArrayList<>();
        Cursor c = db.rawQuery("SELECT _id, nonce, payload FROM records", null);
        try {
            while (c.moveToNext()) {
                ArchivedMessage m = decode(c.getLong(0), c.getBlob(1), c.getBlob(2));
                if (m != null) result.add(m);
            }
        } finally { c.close(); }
        return result;
    }

    private ArchivedMessage decode(long id, byte[] nonce, byte[] payload) {
        try {
            String json = new String(crypto.decryptLocal(nonce, payload, recordAad(id)), StandardCharsets.UTF_8);
            ArchivedMessage m = ArchivedMessage.fromJson(new JSONObject(json));
            m.id = id;
            return m;
        } catch (Exception e) {
            Log.e(TAG, "Skipped unreadable encrypted row id=" + id, e);
            return null;
        }
    }

    private void updateEncrypted(SQLiteDatabase db, ArchivedMessage message) throws Exception {
        CryptoManager.EncryptedBlob blob = crypto.encryptLocal(
                message.toJson().toString().getBytes(StandardCharsets.UTF_8), recordAad(message.id));
        ContentValues values = new ContentValues();
        values.put("nonce", blob.iv);
        values.put("payload", blob.ciphertext);
        db.update("records", values, "_id=?", new String[]{String.valueOf(message.id)});
    }

    public synchronized List<ArchivedMessage> getMessages(String query, String filter) {
        ArrayList<ArchivedMessage> rows = new ArrayList<>(getAllInternal(getReadableDatabase()));
        rows.sort((a, b) -> Long.compare(b.postedAt, a.postedAt));
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        String f = filter == null ? "all" : filter;
        ArrayList<ArchivedMessage> result = new ArrayList<>();
        for (ArchivedMessage m : rows) {
            if ("recall".equals(f) && !"RECALL_EVENT".equals(m.recordType)) continue;
            if ("attachment".equals(f) && m.attachmentPath.isEmpty() && "text".equals(m.messageType)) continue;
            if (!q.isEmpty()) {
                String haystack = (m.conversation + "\n" + m.sender + "\n" + m.content + "\n" + m.messageType).toLowerCase(Locale.ROOT);
                if (!haystack.contains(q)) continue;
            }
            result.add(m);
            if (result.size() >= 500) break; // Bound UI work; search still scans the complete encrypted archive.
        }
        return result;
    }

    public synchronized List<ArchivedMessage> getAllMessages() {
        return getMessages("", "all");
    }

    public synchronized ArchivedMessage getById(long id) {
        Cursor c = getReadableDatabase().rawQuery("SELECT _id, nonce, payload FROM records WHERE _id=?", new String[]{String.valueOf(id)});
        try { return c.moveToFirst() ? decode(c.getLong(0), c.getBlob(1), c.getBlob(2)) : null; }
        finally { c.close(); }
    }

    public synchronized int count() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM records", null);
        try { return c.moveToFirst() ? c.getInt(0) : 0; }
        finally { c.close(); }
    }

    public synchronized int attachmentCount() {
        int count = 0;
        for (ArchivedMessage m : getAllInternal(getReadableDatabase())) if (!m.attachmentPath.isEmpty()) count++;
        return count;
    }

    public synchronized void updateNotificationRemoved(String notificationKey, int reason, long removedAt) {
        if (notificationKey == null || notificationKey.isEmpty()) return;
        SQLiteDatabase db = getWritableDatabase();
        List<ArchivedMessage> rows = getAllInternal(db);
        long latestNotificationPost = 0;
        for (ArchivedMessage m : rows) {
            if (notificationKey.equals(m.notificationKey) && m.notificationPostedAt > latestNotificationPost) {
                latestNotificationPost = m.notificationPostedAt;
            }
        }
        for (ArchivedMessage m : rows) {
            if (notificationKey.equals(m.notificationKey)
                    && m.notificationPostedAt == latestNotificationPost
                    && m.notificationRemovedAt == 0) {
                m.notificationRemovedAt = removedAt;
                m.notificationRemovalReason = reason;
                try { updateEncrypted(db, m); }
                catch (Exception e) { Log.e(TAG, "Failed to update notification event", e); }
            }
        }
    }

    public synchronized void updateLinkedMessage(long recordId, long linkedId) {
        ArchivedMessage m = getById(recordId);
        if (m == null) return;
        m.linkedMessageId = linkedId;
        try { updateEncrypted(getWritableDatabase(), m); }
        catch (Exception e) { Log.e(TAG, "Failed to update recall association", e); }
    }

    /** Encrypt an image preview before writing it to the app-private files directory. */
    public synchronized String saveAttachment(byte[] bytes, String mime) {
        if (bytes == null || bytes.length == 0 || bytes.length > MAX_ATTACHMENT_BYTES) return "";
        if (mime == null || !mime.toLowerCase(Locale.ROOT).startsWith("image/")) return "";
        try {
            String name = UUID.randomUUID().toString().replace("-", "") + ".nva";
            String relativePath = "attachments/" + name;
            CryptoManager.EncryptedBlob blob = crypto.encryptLocal(bytes, relativePath.getBytes(StandardCharsets.UTF_8));
            File target = new File(attachmentDir, name);
            try (FileOutputStream out = new FileOutputStream(target)) {
                out.write(blob.iv);
                out.write(blob.ciphertext);
                out.flush();
            }
            return relativePath;
        } catch (Exception e) {
            Log.e(TAG, "Could not store encrypted image preview", e);
            return "";
        }
    }

    public synchronized byte[] readAttachment(String relativePath) {
        if (relativePath == null || !relativePath.startsWith("attachments/")) return null;
        File file = new File(appContext.getFilesDir(), relativePath);
        try {
            if (!file.getCanonicalPath().startsWith(attachmentDir.getCanonicalPath() + File.separator)) return null;
        } catch (Exception e) {
            return null;
        }
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] all = readLimited(in, MAX_ATTACHMENT_BYTES + 64);
            if (all.length < 12 + 16) return null;
            byte[] iv = new byte[12];
            System.arraycopy(all, 0, iv, 0, 12);
            byte[] encrypted = new byte[all.length - 12];
            System.arraycopy(all, 12, encrypted, 0, encrypted.length);
            return crypto.decryptLocal(iv, encrypted, relativePath.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            Log.w(TAG, "Could not decrypt preview", e);
            return null;
        }
    }

    private void deleteAttachmentFile(String relativePath) {
        if (relativePath == null || !relativePath.startsWith("attachments/")) return;
        try {
            File file = new File(appContext.getFilesDir(), relativePath);
            if (file.getCanonicalPath().startsWith(attachmentDir.getCanonicalPath() + File.separator)) {
                //noinspection ResultOfMethodCallIgnored
                file.delete();
            }
        } catch (Exception ignored) {}
    }

    public synchronized void delete(long id) {
        ArchivedMessage m = getById(id);
        getWritableDatabase().delete("records", "_id=?", new String[]{String.valueOf(id)});
        if (m != null) deleteAttachmentFile(m.attachmentPath);
    }

    public synchronized void clearAll() {
        for (ArchivedMessage m : getAllInternal(getReadableDatabase())) deleteAttachmentFile(m.attachmentPath);
        getWritableDatabase().delete("records", null, null);
    }

    /** Create a portable password-encrypted backup, including readable image previews inside the encrypted payload. */
    public synchronized byte[] createBackup(char[] password) throws Exception {
        JSONObject root = new JSONObject();
        root.put("format", "NVPRO_BACKUP");
        root.put("version", 2);
        root.put("createdAt", System.currentTimeMillis());
        JSONArray rows = new JSONArray();
        JSONObject attachments = new JSONObject();
        for (ArchivedMessage m : getAllInternal(getReadableDatabase())) {
            rows.put(m.toJson());
            if (!m.attachmentPath.isEmpty()) {
                byte[] bytes = readAttachment(m.attachmentPath);
                if (bytes != null && bytes.length <= MAX_ATTACHMENT_BYTES) {
                    attachments.put(m.attachmentPath, Base64.encodeToString(bytes, Base64.NO_WRAP));
                }
            }
        }
        root.put("records", rows);
        root.put("attachments", attachments);
        byte[] plaintext = root.toString().getBytes(StandardCharsets.UTF_8);
        if (plaintext.length > 90 * 1024 * 1024) throw new IllegalStateException("备份超过 90 MB，请减少附件后重试");
        return CryptoManager.encryptBackup(plaintext, password);
    }

    /** Restore and merge a password-encrypted backup. Existing records are not cleared. */
    public synchronized int restoreBackup(byte[] archive, char[] password) throws Exception {
        byte[] plaintext = CryptoManager.decryptBackup(archive, password);
        JSONObject root = new JSONObject(new String(plaintext, StandardCharsets.UTF_8));
        if (!"NVPRO_BACKUP".equals(root.optString("format"))) throw new IllegalArgumentException("备份文件格式不正确");
        int version = root.optInt("version", 0);
        if (version < 1 || version > 2) throw new IllegalArgumentException("不支持的备份版本");
        JSONArray jsonRows = root.optJSONArray("records");
        if (jsonRows == null || jsonRows.length() > MAX_ROWS) throw new IllegalArgumentException("备份记录数量异常");
        JSONObject attachments = root.optJSONObject("attachments");

        ArrayList<ArchivedMessage> messages = new ArrayList<>();
        for (int i = 0; i < jsonRows.length(); i++) {
            ArchivedMessage m = ArchivedMessage.fromJson(jsonRows.getJSONObject(i));
            if (!m.attachmentPath.isEmpty() && attachments != null) {
                String encoded = attachments.optString(m.attachmentPath, "");
                if (!encoded.isEmpty()) {
                    byte[] image = Base64.decode(encoded, Base64.DEFAULT);
                    String newPath = saveAttachment(image, m.attachmentMime);
                    if (!newPath.isEmpty()) m.attachmentPath = newPath;
                    else m.attachmentPath = "";
                } else {
                    m.attachmentPath = "";
                }
            } else {
                m.attachmentPath = "";
            }
            messages.add(m);
        }
        messages.sort(Comparator.comparingLong(m -> m.postedAt));

        SQLiteDatabase db = getWritableDatabase();
        List<ArchivedMessage> history = getAllInternal(db);
        history.sort(Comparator.comparingLong(m -> m.postedAt));
        HashMap<String, ArchivedMessage> existingBySignature = new HashMap<>();
        for (ArchivedMessage existing : history) {
            String signature = duplicateSignature(existing);
            if (signature != null) existingBySignature.put(signature, existing);
        }

        Map<Long, Long> idMap = new HashMap<>();
        int restored = 0;
        for (ArchivedMessage m : messages) {
            long oldId = m.id;
            long oldLink = m.linkedMessageId;
            String signature = duplicateSignature(m);
            ArchivedMessage duplicate = signature == null ? null : existingBySignature.get(signature);
            if (duplicate != null) {
                if (!m.attachmentPath.isEmpty()) {
                    if (duplicate.attachmentPath.isEmpty()) {
                        duplicate.attachmentPath = m.attachmentPath;
                        duplicate.attachmentMime = m.attachmentMime;
                        duplicate.attachmentName = m.attachmentName;
                        updateEncrypted(db, duplicate);
                    } else if (!duplicate.attachmentPath.equals(m.attachmentPath)) {
                        deleteAttachmentFile(m.attachmentPath);
                    }
                }
                idMap.put(oldId, duplicate.id);
                restored++;
                continue;
            }

            m.id = 0;
            if (oldLink > 0 && idMap.containsKey(oldLink)) m.linkedMessageId = idMap.get(oldLink);
            else if (oldLink > 0) m.linkedMessageId = 0;
            if ("RECALL_EVENT".equals(m.recordType) && m.linkedMessageId == 0) {
                ArchivedMessage candidate = findRecallCandidate(history, m);
                if (candidate != null) m.linkedMessageId = candidate.id;
            }
            long newId = insertEncryptedRow(db, m);
            if (newId <= 0) {
                deleteAttachmentFile(m.attachmentPath);
                continue;
            }
            idMap.put(oldId, newId);
            if (signature != null) existingBySignature.put(signature, m);
            history.add(m);
            restored++;
        }
        trimOldRows(db);
        return restored;
    }

    public static String removalReasonLabel(int reason) {
        if (android.os.Build.VERSION.SDK_INT < 26) return "通知已移除";
        switch (reason) {
            case android.service.notification.NotificationListenerService.REASON_CANCEL: return "通知被取消";
            case android.service.notification.NotificationListenerService.REASON_CANCEL_ALL: return "用户清除了全部通知";
            case android.service.notification.NotificationListenerService.REASON_CLICK: return "通知被点击";
            case android.service.notification.NotificationListenerService.REASON_TIMEOUT: return "通知超时";
            case android.service.notification.NotificationListenerService.REASON_SNOOZED: return "通知被暂缓";
            case android.service.notification.NotificationListenerService.REASON_APP_CANCEL: return "应用主动移除通知";
            case android.service.notification.NotificationListenerService.REASON_APP_CANCEL_ALL: return "应用清除了全部通知";
            default: return "通知被移除（原因未分类）";
        }
    }

    private static byte[] recordAad(long id) {
        return ByteBuffer.allocate(8).putLong(id).array();
    }

    private static String safe(String v, String fallback) { return v == null || v.trim().isEmpty() ? fallback : v.trim(); }

    private static byte[] readLimited(FileInputStream in, int max) throws Exception { return readLimited((java.io.InputStream) in, max); }
    private static byte[] readLimited(java.io.InputStream in, int max) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int total = 0;
        int n;
        while ((n = in.read(buffer)) >= 0) {
            total += n;
            if (total > max) throw new IllegalArgumentException("数据超过允许大小");
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }
}
