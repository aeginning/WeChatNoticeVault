package com.nv.noticevault;

import org.json.JSONException;
import org.json.JSONObject;

/** A single archived notification message or an explicitly observed system recall notice. */
public final class ArchivedMessage {
    public long id;
    public long postedAt;
    /** Time the Android notification instance was posted; distinct from the chat message timestamp. */
    public long notificationPostedAt;
    public String conversation = "未命名会话";
    public String sender = "";
    public String content = "";
    /** MESSAGE or RECALL_EVENT. */
    public String recordType = "MESSAGE";
    /** text, image, voice, video, file, unknown. */
    public String messageType = "text";
    /** App-private encrypted attachment path, never a public filesystem path. */
    public String attachmentPath = "";
    public String attachmentMime = "";
    public String attachmentName = "";
    public String notificationKey = "";
    public long notificationRemovedAt;
    public int notificationRemovalReason;
    /** Best-effort candidate only; this is not proof that the message was recalled. */
    public long linkedMessageId;

    public ArchivedMessage() {}

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("postedAt", postedAt);
        o.put("notificationPostedAt", notificationPostedAt);
        o.put("conversation", safe(conversation));
        o.put("sender", safe(sender));
        o.put("content", safe(content));
        o.put("recordType", safe(recordType));
        o.put("messageType", safe(messageType));
        o.put("attachmentPath", safe(attachmentPath));
        o.put("attachmentMime", safe(attachmentMime));
        o.put("attachmentName", safe(attachmentName));
        o.put("notificationKey", safe(notificationKey));
        o.put("notificationRemovedAt", notificationRemovedAt);
        o.put("notificationRemovalReason", notificationRemovalReason);
        o.put("linkedMessageId", linkedMessageId);
        return o;
    }

    public static ArchivedMessage fromJson(JSONObject o) throws JSONException {
        ArchivedMessage m = new ArchivedMessage();
        m.id = o.optLong("id", 0);
        m.postedAt = o.optLong("postedAt", System.currentTimeMillis());
        m.notificationPostedAt = o.optLong("notificationPostedAt", m.postedAt);
        m.conversation = safe(o.optString("conversation", "未命名会话"));
        m.sender = safe(o.optString("sender", ""));
        m.content = safe(o.optString("content", ""));
        m.recordType = safe(o.optString("recordType", "MESSAGE"));
        m.messageType = safe(o.optString("messageType", "text"));
        m.attachmentPath = safe(o.optString("attachmentPath", ""));
        m.attachmentMime = safe(o.optString("attachmentMime", ""));
        m.attachmentName = safe(o.optString("attachmentName", ""));
        m.notificationKey = safe(o.optString("notificationKey", ""));
        m.notificationRemovedAt = o.optLong("notificationRemovedAt", 0);
        m.notificationRemovalReason = o.optInt("notificationRemovalReason", 0);
        m.linkedMessageId = o.optLong("linkedMessageId", 0);
        return m;
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }
}
