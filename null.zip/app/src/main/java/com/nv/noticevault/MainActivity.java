package com.nv.noticevault;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;

/** Chinese UI for encrypted local archive, event timeline, and encrypted backups. */
public final class MainActivity extends Activity {
    private static final int REQUEST_BACKUP_CREATE = 2201;
    private static final int REQUEST_BACKUP_OPEN = 2202;
    private static final int COLOR_BG = 0xFFF3F6FC;
    private static final int COLOR_TEXT = 0xFF17243A;
    private static final int COLOR_MUTED = 0xFF738198;
    private static final int COLOR_BLUE = 0xFF315FEA;
    private static final int COLOR_CARD = 0xFFFFFFFF;

    private MessageStore store;
    private ExecutorService io;
    private LinearLayout root;
    private LinearLayout pageHost;
    private TextView permissionStatus;
    private TextView countStatus;
    private TextView shizukuStatusView;
    private int currentTab = 0;
    private String currentQuery = "";
    private String currentFilter = "all";
    private char[] pendingBackupPassword;
    private boolean appUnlocked;
    private boolean unlockPromptShowing;
    private boolean destroyed;

    private final Shizuku.OnBinderReceivedListener shizukuBinderReceived = this::onShizukuStateChanged;
    private final Shizuku.OnBinderDeadListener shizukuBinderDead = this::onShizukuStateChanged;
    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionResult = (requestCode, grantResult) -> {
        if (requestCode == ShizukuSupport.REQUEST_CODE) {
            runOnUiThread(() -> {
                toast(grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED
                        ? "Shizuku 授权已通过" : "Shizuku 授权未通过");
                refreshShizukuCard();
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new MessageStore(this);
        io = Executors.newSingleThreadExecutor();
        registerShizukuCallbacks();
        appUnlocked = !getPreferences(MODE_PRIVATE).getBoolean("app_lock_enabled", false);
        applySecureWindowFlag();
        buildShell();
        refreshHeader();
        if (!appUnlocked) requestUnlock();
        else renderCurrentPage();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshHeader();
        refreshShizukuCard();
        applySecureWindowFlag();
        if (getPreferences(MODE_PRIVATE).getBoolean("app_lock_enabled", false) && !appUnlocked && !unlockPromptShowing) {
            requestUnlock();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (getPreferences(MODE_PRIVATE).getBoolean("app_lock_enabled", false) && appUnlocked && !unlockPromptShowing) {
            appUnlocked = false;
        }
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(COLOR_BG);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        TextView brand = text("消息留存 PRO", 25, COLOR_TEXT, true);
        header.addView(brand, matchWrap());
        TextView subtitle = text("微信通知归档 · 本地加密 · 撤回事件线索", 12, COLOR_MUTED, false);
        subtitle.setPadding(0, dp(3), 0, dp(12));
        header.addView(subtitle, matchWrap());
        root.addView(header, matchWrap());

        LinearLayout permissionCard = card();
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView label = text("监听状态", 14, COLOR_TEXT, true);
        statusRow.addView(label, new LinearLayout.LayoutParams(0, dp(28), 1));
        Button settings = smallButton("权限设置");
        settings.setOnClickListener(v -> openNotificationSettings());
        statusRow.addView(settings, wrap());
        permissionCard.addView(statusRow, matchWrap());
        permissionStatus = text("正在检查通知读取权限…", 12, COLOR_MUTED, false);
        permissionStatus.setPadding(0, dp(6), 0, 0);
        permissionCard.addView(permissionStatus, matchWrap());
        root.addView(permissionCard, bottomParams(10));

        countStatus = text("记录 0 条", 12, COLOR_MUTED, true);
        countStatus.setPadding(dp(2), 0, 0, dp(8));
        root.addView(countStatus, matchWrap());

        pageHost = new LinearLayout(this);
        pageHost.setOrientation(LinearLayout.VERTICAL);
        root.addView(pageHost, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(0, dp(8), 0, dp(2));
        nav.setBackground(roundDrawable(0xFFFFFFFF, 18));
        nav.addView(navButton("消息", 0), new LinearLayout.LayoutParams(0, dp(48), 1));
        nav.addView(navButton("时间线", 1), new LinearLayout.LayoutParams(0, dp(48), 1));
        nav.addView(navButton("设置", 2), new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(nav, bottomParams(0));
        setContentView(root);
    }

    private View navButton(String label, int tab) {
        TextView button = text(label, 14, tab == currentTab ? COLOR_BLUE : COLOR_MUTED, tab == currentTab);
        button.setGravity(Gravity.CENTER);
        button.setOnClickListener(v -> {
            currentTab = tab;
            renderCurrentPage();
            buildShellNavState();
        });
        return button;
    }

    private void buildShellNavState() {
        // Rebuild the lower navigation strip with its active state while keeping current page content.
        if (root == null) return;
        View oldNav = root.getChildAt(root.getChildCount() - 1);
        if (!(oldNav instanceof LinearLayout)) return;
        LinearLayout nav = (LinearLayout) oldNav;
        nav.removeAllViews();
        nav.addView(navButton("消息", 0), new LinearLayout.LayoutParams(0, dp(48), 1));
        nav.addView(navButton("时间线", 1), new LinearLayout.LayoutParams(0, dp(48), 1));
        nav.addView(navButton("设置", 2), new LinearLayout.LayoutParams(0, dp(48), 1));
    }

    private void refreshHeader() {
        if (permissionStatus == null || countStatus == null || store == null) return;
        boolean enabled = isListenerEnabled();
        permissionStatus.setText(enabled
                ? "已授权：仅处理 com.tencent.mm 的新通知。通知正文不完整时无法恢复缺失内容。"
                : "尚未授权：打开系统通知使用权后，才会开始归档新的微信通知。");
        permissionStatus.setTextColor(enabled ? 0xFF147A54 : 0xFF9A5C12);
        int records = store.count();
        countStatus.setText("已加密保存 " + records + " 条 · 上限 " + MessageStore.MAX_ROWS + " 条");
    }

    private boolean isListenerEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        if (enabled == null) return false;
        String expected = getPackageName() + "/" + WeChatNotificationListener.class.getName();
        for (String component : enabled.split(":")) if (expected.equalsIgnoreCase(component)) return true;
        return false;
    }

    private void openNotificationSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        } catch (Exception e) {
            toast("无法打开系统设置，请在设置中搜索“通知使用权”");
        }
    }

    private void renderCurrentPage() {
        if (pageHost == null) return;
        pageHost.removeAllViews();
        if (currentTab == 0) renderMessagesPage();
        else if (currentTab == 1) renderTimelinePage();
        else renderSettingsPage();
    }

    private void renderMessagesPage() {
        EditText search = searchBox("搜索会话、联系人或消息全文");
        search.setText(currentQuery);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                currentQuery = s.toString();
                loadRecords(false);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        pageHost.addView(search, bottomParams(8));

        LinearLayout filters = new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        filters.addView(filterButton("全部", "all"), new LinearLayout.LayoutParams(0, dp(38), 1));
        filters.addView(filterButton("撤回提示", "recall"), new LinearLayout.LayoutParams(0, dp(38), 1));
        filters.addView(filterButton("附件", "attachment"), new LinearLayout.LayoutParams(0, dp(38), 1));
        pageHost.addView(filters, bottomParams(8));

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.addView(list, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pageHost.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        list.setTag("record_list");
        loadRecords(false);
    }

    private View filterButton(String label, String filter) {
        TextView b = text(label, 12, filter.equals(currentFilter) ? 0xFFFFFFFF : COLOR_MUTED, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundDrawable(filter.equals(currentFilter) ? COLOR_BLUE : 0xFFFFFFFF, 12));
        b.setOnClickListener(v -> {
            currentFilter = filter;
            renderCurrentPage();
        });
        return b;
    }

    private void loadRecords(boolean timeline) {
        if (io == null || io.isShutdown()) return;
        final String query = currentQuery;
        final String filter = timeline ? "all" : currentFilter;
        io.execute(() -> {
            List<ArchivedMessage> rows = store.getMessages(query, filter);
            runOnUiThread(() -> {
                if (destroyed || pageHost == null || (currentTab != 0 && currentTab != 1)) return;
                if (currentTab == 0 && !timeline) populateMessageList(rows);
                if (currentTab == 1 && timeline) populateTimeline(rows);
            });
        });
    }

    private void populateMessageList(List<ArchivedMessage> rows) {
        View found = pageHost.findViewWithTag("record_list");
        if (!(found instanceof LinearLayout)) return;
        LinearLayout list = (LinearLayout) found;
        list.removeAllViews();
        if (rows.isEmpty()) {
            list.addView(emptyState("暂无匹配记录", "授权通知读取后，让微信收到一条带有正文预览的消息。"), matchWrap());
            return;
        }
        for (int i = 0; i < rows.size(); i++) list.addView(recordCard(rows.get(i), false, i < 40), bottomParams(9));
    }

    private void renderTimelinePage() {
        TextView intro = text("通知与消息事件按时间倒序排列。通知移除不等于撤回。", 12, COLOR_MUTED, false);
        intro.setPadding(dp(2), 0, 0, dp(8));
        pageHost.addView(intro, matchWrap());
        EditText search = searchBox("搜索时间线");
        search.setText(currentQuery);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                currentQuery = s.toString();
                loadRecords(true);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        pageHost.addView(search, bottomParams(8));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pageHost.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        list.setTag("timeline_list");
        loadRecords(true);
    }

    private void populateTimeline(List<ArchivedMessage> rows) {
        View found = pageHost.findViewWithTag("timeline_list");
        if (!(found instanceof LinearLayout)) return;
        LinearLayout list = (LinearLayout) found;
        list.removeAllViews();
        if (rows.isEmpty()) {
            list.addView(emptyState("时间线为空", "收到微信通知后，消息会显示在这里。"), matchWrap());
            return;
        }
        String previousDay = "";
        SimpleDateFormat dayFormat = new SimpleDateFormat("yyyy年MM月dd日", Locale.getDefault());
        for (ArchivedMessage m : rows) {
            String day = dayFormat.format(new Date(m.postedAt));
            if (!day.equals(previousDay)) {
                TextView heading = text(day, 12, COLOR_BLUE, true);
                heading.setPadding(dp(3), dp(8), 0, dp(5));
                list.addView(heading, matchWrap());
                previousDay = day;
            }
            list.addView(recordCard(m, true, list.getChildCount() < 40), bottomParams(8));
        }
    }

    private View recordCard(ArchivedMessage m, boolean timeline, boolean allowInlinePreview) {
        LinearLayout item = card();
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView conversation = text(m.conversation, 14, COLOR_TEXT, true);
        top.addView(conversation, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        String badge = "RECALL_EVENT".equals(m.recordType) ? "撤回提示" : labelForType(m.messageType);
        TextView type = text(badge, 10, "RECALL_EVENT".equals(m.recordType) ? 0xFFB45309 : COLOR_BLUE, true);
        type.setPadding(dp(8), dp(4), dp(8), dp(4));
        type.setBackground(roundDrawable("RECALL_EVENT".equals(m.recordType) ? 0xFFFFF2D9 : 0xFFEAF0FF, 10));
        top.addView(type, wrap());
        item.addView(top, matchWrap());

        String meta = formatTime(m.postedAt);
        if (!m.sender.isEmpty()) meta = m.sender + " · " + meta;
        TextView metadata = text(meta, 10, COLOR_MUTED, false);
        metadata.setPadding(0, dp(4), 0, dp(7));
        item.addView(metadata, matchWrap());

        TextView body = text(m.content.isEmpty() ? "[仅捕获到附件元数据]" : m.content, 13, 0xFF34445C, false);
        body.setMaxLines(timeline ? 3 : 5);
        item.addView(body, matchWrap());

        if (!m.attachmentPath.isEmpty() && m.messageType.equals("image")) {
            byte[] imageBytes = allowInlinePreview ? store.readAttachment(m.attachmentPath) : null;
            if (!allowInlinePreview) {
                TextView saved = text("图片预览已加密保存 · 点击查看", 11, COLOR_MUTED, false);
                saved.setPadding(0, dp(5), 0, 0);
                item.addView(saved, matchWrap());
            } else if (imageBytes != null) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                if (bitmap != null) {
                    ImageView preview = new ImageView(this);
                    preview.setImageBitmap(bitmap);
                    preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    preview.setBackground(roundDrawable(0xFFE9EDF4, 12));
                    LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(168), dp(112));
                    p.topMargin = dp(9);
                    item.addView(preview, p);
                }
            } else {
                TextView unavailable = text("图片预览未能读取（可能无 URI 读取授权）", 11, COLOR_MUTED, false);
                unavailable.setPadding(0, dp(5), 0, 0);
                item.addView(unavailable, matchWrap());
            }
        } else if (!m.attachmentMime.isEmpty() && !"text".equals(m.messageType)) {
            TextView attachment = text("附件类型：" + m.attachmentMime + (m.attachmentName.isEmpty() ? "" : " · " + m.attachmentName), 11, COLOR_MUTED, false);
            attachment.setPadding(0, dp(5), 0, 0);
            item.addView(attachment, matchWrap());
        }

        if ("RECALL_EVENT".equals(m.recordType)) {
            String link = m.linkedMessageId > 0 ? "可能关联到此前一条消息（仅供核对）" : "未找到足够可靠的关联消息";
            TextView association = text(link, 11, 0xFF9A5C12, true);
            association.setPadding(0, dp(7), 0, 0);
            item.addView(association, matchWrap());
        }
        if (m.notificationRemovedAt > 0) {
            TextView removed = text("通知变化：" + MessageStore.removalReasonLabel(m.notificationRemovalReason) + " · " + formatTime(m.notificationRemovedAt) + "（不是撤回判定）", 10, COLOR_MUTED, false);
            removed.setPadding(0, dp(7), 0, 0);
            item.addView(removed, matchWrap());
        }

        item.setOnClickListener(v -> showMessageDetails(m));
        return item;
    }

    private void renderSettingsPage() {
        ScrollView settingsScroll = new ScrollView(this);
        settingsScroll.setFillViewport(false);
        LinearLayout settingsContent = new LinearLayout(this);
        settingsContent.setOrientation(LinearLayout.VERTICAL);
        settingsContent.setPadding(0, 0, 0, dp(4));
        settingsScroll.addView(settingsContent, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout shizuku = card();
        shizuku.addView(text("Shizuku ADB 增强", 16, COLOR_TEXT, true), matchWrap());
        TextView shizukuIntro = text("连接 Shizuku 后，可检查 ADB Shell 身份、应用授权及系统状态。此增强为可选能力；Shizuku 断开时，原有通知归档仍正常工作。", 12, COLOR_MUTED, false);
        shizukuIntro.setPadding(0, dp(6), 0, dp(8));
        shizuku.addView(shizukuIntro, matchWrap());
        shizukuStatusView = text("正在检测 Shizuku…", 12, COLOR_TEXT, false);
        shizukuStatusView.setPadding(dp(10), dp(9), dp(10), dp(9));
        shizukuStatusView.setBackground(roundDrawable(0xFFF1F4FA, 10));
        shizuku.addView(shizukuStatusView, bottomParams(8));
        Button request = primaryButton("检查 / 请求 Shizuku 授权");
        request.setOnClickListener(v -> requestShizukuPermission());
        shizuku.addView(request, bottomParams(7));
        Button openShizuku = secondaryButton("打开 Shizuku 应用");
        openShizuku.setOnClickListener(v -> openShizukuApp());
        shizuku.addView(openShizuku, bottomParams(7));
        Button battery = secondaryButton("打开电池优化设置");
        battery.setOnClickListener(v -> openBatteryOptimizationSettings());
        shizuku.addView(battery, bottomParams(7));
        Button xiaomi = secondaryButton("小米自启动 / 后台设置");
        xiaomi.setOnClickListener(v -> openXiaomiBackgroundSettings());
        shizuku.addView(xiaomi, matchWrap());
        settingsContent.addView(shizuku, bottomParams(10));

        LinearLayout security = card();
        security.addView(text("本地安全", 16, COLOR_TEXT, true), matchWrap());
        TextView securityInfo = text("消息正文和附件采用 AES-GCM 加密；密钥由 Android Keystore 管理。全文搜索在本机解密后完成，不建立明文搜索索引。", 12, COLOR_MUTED, false);
        securityInfo.setPadding(0, dp(6), 0, dp(10));
        security.addView(securityInfo, matchWrap());
        Switch lock = new Switch(this);
        lock.setText("打开应用时要求设备身份验证");
        lock.setTextColor(COLOR_TEXT);
        lock.setTextSize(13);
        lock.setChecked(getPreferences(MODE_PRIVATE).getBoolean("app_lock_enabled", false));
        lock.setOnCheckedChangeListener((buttonView, checked) -> {
            if (checked) {
                KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                if (km == null || !km.isDeviceSecure()) {
                    lock.setChecked(false);
                    toast("请先在 Android 系统中设置锁屏密码、图案或指纹");
                    return;
                }
                getPreferences(MODE_PRIVATE).edit().putBoolean("app_lock_enabled", true).apply();
                applySecureWindowFlag();
                appUnlocked = false;
                requestUnlock();
            } else {
                getPreferences(MODE_PRIVATE).edit().putBoolean("app_lock_enabled", false).apply();
                applySecureWindowFlag();
                appUnlocked = true;
            }
        });
        security.addView(lock, matchWrap());
        settingsContent.addView(security, bottomParams(10));

        LinearLayout backup = card();
        backup.addView(text("加密备份与恢复", 16, COLOR_TEXT, true), matchWrap());
        TextView backupInfo = text("备份文件使用独立密码和 PBKDF2 + AES-256-GCM 加密，可迁移到另一台设备。恢复采用合并模式，不会自动清空当前记录。请妥善保管备份密码。", 12, COLOR_MUTED, false);
        backupInfo.setPadding(0, dp(6), 0, dp(10));
        backup.addView(backupInfo, matchWrap());
        Button export = primaryButton("创建加密备份");
        export.setOnClickListener(v -> askBackupPassword());
        backup.addView(export, bottomParams(8));
        Button restore = secondaryButton("从备份恢复");
        restore.setOnClickListener(v -> askRestorePassword());
        backup.addView(restore, matchWrap());
        settingsContent.addView(backup, bottomParams(10));

        LinearLayout management = card();
        management.addView(text("数据管理", 16, COLOR_TEXT, true), matchWrap());
        Button clear = secondaryButton("清空全部本地记录");
        clear.setOnClickListener(v -> confirmClear());
        management.addView(clear, bottomParams(8));
        Button system = secondaryButton("打开通知读取权限设置");
        system.setOnClickListener(v -> openNotificationSettings());
        management.addView(system, matchWrap());
        TextView note = text("卸载应用会删除本机数据库和 Keystore 密钥。跨设备或重装前，请先创建加密备份。", 11, COLOR_MUTED, false);
        note.setPadding(0, dp(9), 0, 0);
        management.addView(note, matchWrap());
        settingsContent.addView(management, bottomParams(10));

        TextView about = text("消息留存 PRO 2.1.0 · Android 8.0+ · 本地加密 · 无网络上传权限", 10, COLOR_MUTED, false);
        about.setGravity(Gravity.CENTER);
        about.setPadding(0, dp(8), 0, dp(12));
        settingsContent.addView(about, matchWrap());
        pageHost.addView(settingsScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        refreshShizukuCard();
    }

    private void registerShizukuCallbacks() {
        try {
            Shizuku.addBinderReceivedListenerSticky(shizukuBinderReceived);
            Shizuku.addBinderDeadListener(shizukuBinderDead);
            Shizuku.addRequestPermissionResultListener(shizukuPermissionResult);
        } catch (Throwable ignored) {
            // Shizuku is optional; the core notification archive remains usable.
        }
    }

    private void onShizukuStateChanged() {
        runOnUiThread(this::refreshShizukuCard);
    }

    private void refreshShizukuCard() {
        if (shizukuStatusView == null) return;
        try {
            shizukuStatusView.setText(ShizukuSupport.buildReport(this));
        } catch (Throwable e) {
            shizukuStatusView.setText("暂时无法读取 Shizuku 状态。请检查 Shizuku 是否已启动，然后重新打开本页。\n\n原有通知留存功能不受影响。");
        }
    }

    private void requestShizukuPermission() {
        if (!ShizukuSupport.isConnected()) {
            toast(ShizukuSupport.isInstalled(this)
                    ? "Shizuku 尚未连接。请先打开 Shizuku，使用无线调试启动服务后返回此页。"
                    : "尚未安装 Shizuku。请先安装官方 Shizuku 应用。");
            if (ShizukuSupport.isInstalled(this)) openShizukuApp();
            else openShizukuDownloadPage();
            return;
        }
        try {
            if (Shizuku.isPreV11()) {
                toast("当前 Shizuku 服务版本过旧，请更新 Shizuku 后重试。");
                return;
            }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                toast("Shizuku 已授权，无需重复操作。");
                refreshShizukuCard();
                return;
            }
            Shizuku.requestPermission(ShizukuSupport.REQUEST_CODE);
        } catch (Throwable e) {
            toast("请求 Shizuku 授权失败：" + (e.getMessage() == null ? "请重启 Shizuku 后重试" : e.getMessage()));
        }
    }

    private void openShizukuApp() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (launch == null) {
                openShizukuDownloadPage();
                return;
            }
            startActivity(launch);
        } catch (Exception e) {
            openShizukuDownloadPage();
        }
    }

    private void openShizukuDownloadPage() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")));
        } catch (Exception e) {
            toast("请从 Shizuku 官方网站下载安装：shizuku.rikka.app");
        }
    }

    private void openBatteryOptimizationSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        } catch (Exception e) {
            openAppDetailsSettings();
        }
    }

    private void openXiaomiBackgroundSettings() {
        if (!android.os.Build.MANUFACTURER.toLowerCase(Locale.ROOT).contains("xiaomi")) {
            toast("此入口主要针对小米设备；当前设备可在应用信息中检查后台运行设置。");
            openAppDetailsSettings();
            return;
        }
        try {
            Intent intent = new Intent("miui.intent.action.OP_AUTO_START");
            intent.setPackage("com.miui.securitycenter");
            startActivity(intent);
        } catch (Exception e) {
            toast("当前 MIUI / HyperOS 版本未提供此快捷入口，请从系统设置 → 应用设置 → 应用管理中查找自启动权限。");
            openAppDetailsSettings();
        }
    }

    private void openAppDetailsSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            toast("无法打开应用详情设置，请在系统设置中查找“消息留存 PRO”。");
        }
    }

    private EditText searchBox(String hint) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setTextSize(13);
        edit.setHint(hint);
        edit.setPadding(dp(13), 0, dp(13), 0);
        edit.setBackground(roundDrawable(0xFFFFFFFF, 12));
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        return edit;
    }

    private void showMessageDetails(ArchivedMessage m) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(5), dp(8), dp(5));
        TextView meta = text("会话：" + m.conversation + "\n发送者：" + (m.sender.isEmpty() ? "未知" : m.sender) + "\n时间：" + formatTime(m.postedAt), 12, COLOR_MUTED, false);
        content.addView(meta, matchWrap());
        TextView body = text("\n" + (m.content.isEmpty() ? "[无正文]" : m.content), 14, COLOR_TEXT, false);
        content.addView(body, matchWrap());
        if (!m.attachmentPath.isEmpty()) {
            byte[] bytes = store.readAttachment(m.attachmentPath);
            if (bytes != null) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap != null) {
                    ImageView image = new ImageView(this);
                    image.setImageBitmap(bitmap);
                    image.setAdjustViewBounds(true);
                    image.setMaxHeight(dp(260));
                    image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    content.addView(image, bottomParams(8));
                }
            }
        }
        if (m.linkedMessageId > 0) {
            ArchivedMessage linked = store.getById(m.linkedMessageId);
            TextView association = text("\n可能关联消息：" + (linked == null ? "记录已不存在" : linked.content), 12, 0xFF9A5C12, false);
            content.addView(association, matchWrap());
        }
        if (m.notificationRemovedAt > 0) {
            TextView removed = text("\n通知移除信息：" + MessageStore.removalReasonLabel(m.notificationRemovalReason) + "\n" + formatTime(m.notificationRemovedAt) + "\n注意：这不是撤回的确定证据。", 11, COLOR_MUTED, false);
            content.addView(removed, matchWrap());
        }
        new AlertDialog.Builder(this)
                .setTitle("记录详情 · " + labelForType(m.messageType))
                .setView(content)
                .setNegativeButton("关闭", null)
                .setNeutralButton("删除此条", (dialog, which) -> {
                    store.delete(m.id);
                    refreshHeader();
                    renderCurrentPage();
                })
                .show();
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("清空全部记录？")
                .setMessage("将删除所有加密消息记录和本地图片预览，无法撤销。建议先创建加密备份。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确认清空", (dialog, which) -> {
                    store.clearAll();
                    refreshHeader();
                    renderCurrentPage();
                }).show();
    }

    private void askBackupPassword() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(8), dp(4), dp(8), 0);
        EditText first = new EditText(this);
        first.setSingleLine(true);
        first.setHint("设置备份密码（至少 8 位）");
        first.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText second = new EditText(this);
        second.setSingleLine(true);
        second.setHint("再次输入备份密码");
        second.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        form.addView(first, matchWrap());
        form.addView(second, matchWrap());
        new AlertDialog.Builder(this)
                .setTitle("创建加密备份")
                .setMessage("请设置独立备份密码。密码不会上传，也无法由开发者找回。")
                .setView(form)
                .setNegativeButton("取消", null)
                .setPositiveButton("继续", (dialog, which) -> {
                    String a = first.getText().toString();
                    String b = second.getText().toString();
                    if (a.length() < 8 || !a.equals(b)) {
                        toast("密码至少 8 位，且两次输入必须一致");
                        return;
                    }
                    wipePendingPassword();
                    pendingBackupPassword = a.toCharArray();
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/octet-stream");
                    intent.putExtra(Intent.EXTRA_TITLE, "消息留存PRO_加密备份.nvbackup");
                    startActivityForResult(intent, REQUEST_BACKUP_CREATE);
                }).show();
    }

    private void askRestorePassword() {
        EditText password = new EditText(this);
        password.setSingleLine(true);
        password.setHint("输入创建备份时设置的密码");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        new AlertDialog.Builder(this)
                .setTitle("恢复加密备份")
                .setMessage("恢复会将备份记录合并到当前数据库，不会自动清空现有内容。")
                .setView(password)
                .setNegativeButton("取消", null)
                .setPositiveButton("选择备份文件", (dialog, which) -> {
                    String value = password.getText().toString();
                    if (value.length() < 8) {
                        toast("请输入有效备份密码");
                        return;
                    }
                    wipePendingPassword();
                    pendingBackupPassword = value.toCharArray();
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    startActivityForResult(intent, REQUEST_BACKUP_OPEN);
                }).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_BACKUP_CREATE && requestCode != REQUEST_BACKUP_OPEN) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            wipePendingPassword();
            return;
        }
        Uri uri = data.getData();
        char[] password = pendingBackupPassword == null ? new char[0] : pendingBackupPassword.clone();
        wipePendingPassword();
        if (io == null || io.isShutdown()) {
            Arrays.fill(password, '\0');
            return;
        }
        io.execute(() -> {
            try {
                if (requestCode == REQUEST_BACKUP_CREATE) {
                    byte[] archive = store.createBackup(password);
                    try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                        if (out == null) throw new IllegalStateException("无法写入所选文件");
                        out.write(archive);
                        out.flush();
                    }
                    runOnUiThread(() -> toast("加密备份已保存"));
                } else {
                    byte[] archive;
                    try (InputStream in = getContentResolver().openInputStream(uri)) {
                        if (in == null) throw new IllegalStateException("无法读取所选文件");
                        archive = readLimited(in, 100 * 1024 * 1024);
                    }
                    int restored = store.restoreBackup(archive, password);
                    runOnUiThread(() -> {
                        refreshHeader();
                        renderCurrentPage();
                        toast("恢复完成，合并处理 " + restored + " 条记录");
                    });
                }
            } catch (Exception e) {
                final String message = e.getMessage() == null ? "操作失败，请检查文件和密码" : e.getMessage();
                runOnUiThread(() -> toast("备份操作失败：" + message));
            } finally {
                Arrays.fill(password, '\0');
            }
        });
    }

    private byte[] readLimited(InputStream in, int maxBytes) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int total = 0;
        int n;
        while ((n = in.read(buffer)) >= 0) {
            total += n;
            if (total > maxBytes) throw new IllegalArgumentException("备份文件超过 100 MB");
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }

    private void requestUnlock() {
        if (unlockPromptShowing || isFinishing()) return;
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (km == null || !km.isDeviceSecure()) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("app_lock_enabled", false).apply();
            applySecureWindowFlag();
            appUnlocked = true;
            toast("设备没有安全锁屏，已关闭应用锁");
            renderCurrentPage();
            return;
        }
        unlockPromptShowing = true;
        BiometricPrompt prompt = new BiometricPrompt(this, ContextCompat.getMainExecutor(this),
                new BiometricPrompt.AuthenticationCallback() {
                    @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        unlockPromptShowing = false;
                        appUnlocked = true;
                        renderCurrentPage();
                    }
                    @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                        super.onAuthenticationError(errorCode, errString);
                        unlockPromptShowing = false;
                        if (!isFinishing()) finish();
                    }
                });
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("解锁消息留存 PRO")
                .setSubtitle("使用设备指纹或锁屏凭据验证身份")
                .setDeviceCredentialAllowed(true)
                .build();
        prompt.authenticate(info);
    }

    private void applySecureWindowFlag() {
        boolean enabled = getPreferences(MODE_PRIVATE).getBoolean("app_lock_enabled", false);
        if (enabled) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }

    private void wipePendingPassword() {
        if (pendingBackupPassword != null) Arrays.fill(pendingBackupPassword, '\0');
        pendingBackupPassword = null;
    }

    private View emptyState(String title, String detail) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setPadding(dp(16), dp(36), dp(16), dp(36));
        wrap.addView(text(title, 15, COLOR_TEXT, true), matchWrap());
        TextView hint = text(detail, 12, COLOR_MUTED, false);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(7), 0, 0);
        wrap.addView(hint, matchWrap());
        return wrap;
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(14), dp(12), dp(14), dp(12));
        layout.setBackground(roundDrawable(COLOR_CARD, 16));
        return layout;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(true);
        return t;
    }

    private Button primaryButton(String label) {
        Button b = button(label, COLOR_BLUE, 0xFFFFFFFF);
        return b;
    }

    private Button secondaryButton(String label) {
        Button b = button(label, 0xFFEAF0FF, COLOR_BLUE);
        return b;
    }

    private Button smallButton(String label) {
        Button b = button(label, 0xFFEAF0FF, COLOR_BLUE);
        b.setTextSize(11);
        b.setMinHeight(dp(34));
        b.setPadding(dp(10), 0, dp(10), 0);
        return b;
    }

    private Button button(String label, int background, int foreground) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTextColor(foreground);
        b.setAllCaps(false);
        b.setMinHeight(dp(42));
        b.setPadding(dp(10), dp(3), dp(10), dp(3));
        b.setBackground(roundDrawable(background, 12));
        return b;
    }

    private GradientDrawable roundDrawable(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams bottomParams(int marginDp) {
        LinearLayout.LayoutParams p = matchWrap();
        p.bottomMargin = dp(marginDp);
        return p;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private String formatTime(long time) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date(time));
    }

    private String labelForType(String type) {
        if ("image".equals(type)) return "图片";
        if ("voice".equals(type)) return "语音";
        if ("video".equals(type)) return "视频";
        if ("file".equals(type)) return "文件";
        if ("unknown".equals(type)) return "其他";
        return "文字";
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    @Override
    protected void onDestroy() {
        destroyed = true;
        wipePendingPassword();
        try {
            Shizuku.removeBinderReceivedListener(shizukuBinderReceived);
            Shizuku.removeBinderDeadListener(shizukuBinderDead);
            Shizuku.removeRequestPermissionResultListener(shizukuPermissionResult);
        } catch (Throwable ignored) { }
        if (io != null && !io.isShutdown()) {
            MessageStore closingStore = store;
            io.execute(() -> { if (closingStore != null) closingStore.close(); });
            io.shutdown();
        } else if (store != null) {
            store.close();
        }
        super.onDestroy();
    }
}
