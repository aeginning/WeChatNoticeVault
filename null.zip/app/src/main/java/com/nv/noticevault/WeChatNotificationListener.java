package com.nv.noticevault;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.util.Log;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Notification listener: only archives notifications from the official WeChat package. */
public final class WeChatNotificationListener extends NotificationListenerService {
    public static final String WECHAT_PACKAGE = "com.tencent.mm";
    private static final String TAG = "NVProListener";
    private ExecutorService worker;
    private MessageStore store;

    @Override
    public void onCreate() {
        super.onCreate();
        worker = Executors.newSingleThreadExecutor();
        store = new MessageStore(getApplicationContext());
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !WECHAT_PACKAGE.equals(sbn.getPackageName())) return;
        Notification notification = sbn.getNotification();
        if (notification == null || notification.extras == null) return;
        if ((notification.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if (worker == null || worker.isShutdown()) return;

        final long postTime = sbn.getPostTime() > 0 ? sbn.getPostTime() : System.currentTimeMillis();
        CharSequence conversationTitle = notification.extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE);
        if (TextUtils.isEmpty(conversationTitle)) conversationTitle = notification.extras.getCharSequence(Notification.EXTRA_TITLE);
        final String conversation = conversationTitle == null || conversationTitle.length() == 0
                ? "微信通知" : conversationTitle.toString();
        final String notificationKey = sbn.getKey() == null ? "" : sbn.getKey();
        worker.execute(() -> {
            try {
                List<NotificationTextExtractor.ParsedItem> parsed =
                        NotificationTextExtractor.extract(getApplicationContext(), notification, postTime);
                for (NotificationTextExtractor.ParsedItem item : parsed) {
                    if (item == null) continue;
                    if (TextUtils.isEmpty(item.content) && item.previewBytes == null) continue;
                    ArchivedMessage message = new ArchivedMessage();
                    message.postedAt = item.timestamp > 0 ? item.timestamp : postTime;
                    message.notificationPostedAt = postTime;
                    message.conversation = conversation;
                    message.sender = item.sender;
                    message.content = item.content;
                    message.messageType = item.messageType;
                    message.attachmentMime = item.attachmentMime;
                    message.attachmentName = item.attachmentName;
                    message.notificationKey = notificationKey;
                    if (RecallDetector.isExplicitRecallNotice(message.content)) {
                        message.recordType = "RECALL_EVENT";
                        message.messageType = "text";
                    }
                    if (item.previewBytes != null && item.previewBytes.length > 0) {
                        message.attachmentPath = store.saveAttachment(item.previewBytes, item.attachmentMime);
                    }
                    store.add(message);
                }
            } catch (Exception e) {
                Log.e(TAG, "Failed to archive WeChat notification", e);
            }
        });
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn, RankingMap rankingMap, int reason) {
        super.onNotificationRemoved(sbn, rankingMap, reason);
        if (sbn == null || !WECHAT_PACKAGE.equals(sbn.getPackageName())) return;
        if (worker == null || worker.isShutdown()) return;
        String key = sbn.getKey();
        worker.execute(() -> store.updateNotificationRemoved(key, reason, System.currentTimeMillis()));
    }

    @Override
    public void onListenerDisconnected() {
        super.onListenerDisconnected();
        // Android can reconnect this listener after the user re-enables notification access.
    }

    @Override
    public void onDestroy() {
        if (worker != null && !worker.isShutdown()) {
            MessageStore closingStore = store;
            worker.execute(() -> { if (closingStore != null) closingStore.close(); });
            worker.shutdown();
        } else if (store != null) {
            store.close();
        }
        super.onDestroy();
    }
}
