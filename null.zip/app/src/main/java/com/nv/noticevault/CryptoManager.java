package com.nv.noticevault;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/** AES-GCM at-rest encryption using a non-exportable Android Keystore key. */
public final class CryptoManager {
    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String KEY_ALIAS = "nvpro_local_aes_256_v2";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final int GCM_TAG_BITS = 128;
    private static final int IV_BYTES = 12;
    private static final byte[] BACKUP_MAGIC = "NVPRO2BK".getBytes(StandardCharsets.US_ASCII);
    private static final int BACKUP_ITERATIONS = 250_000;
    private static final int SALT_BYTES = 16;
    private static final int MAX_BACKUP_BYTES = 100 * 1024 * 1024;

    public static final class EncryptedBlob {
        public final byte[] iv;
        public final byte[] ciphertext;
        EncryptedBlob(byte[] iv, byte[] ciphertext) {
            this.iv = iv;
            this.ciphertext = ciphertext;
        }
    }

    public void ensureKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) return;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build();
        generator.init(spec);
        generator.generateKey();
    }

    private SecretKey localKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        return (SecretKey) ks.getKey(KEY_ALIAS, null);
    }

    public EncryptedBlob encryptLocal(byte[] plaintext) throws Exception {
        return encryptLocal(plaintext, null);
    }

    public EncryptedBlob encryptLocal(byte[] plaintext, byte[] associatedData) throws Exception {
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, localKey());
        if (associatedData != null && associatedData.length > 0) cipher.updateAAD(associatedData);
        byte[] iv = cipher.getIV();
        return new EncryptedBlob(iv, cipher.doFinal(plaintext));
    }

    public byte[] decryptLocal(byte[] iv, byte[] ciphertext) throws Exception {
        return decryptLocal(iv, ciphertext, null);
    }

    public byte[] decryptLocal(byte[] iv, byte[] ciphertext, byte[] associatedData) throws Exception {
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, localKey(), new GCMParameterSpec(GCM_TAG_BITS, iv));
        if (associatedData != null && associatedData.length > 0) cipher.updateAAD(associatedData);
        return cipher.doFinal(ciphertext);
    }

    /** Password-based portable backup. Format: magic, iterations, salt, IV, ciphertext length, ciphertext. */
    public static byte[] encryptBackup(byte[] plaintext, char[] password) throws Exception {
        if (password == null || password.length < 8) throw new IllegalArgumentException("备份密码至少需要 8 个字符");
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_BYTES];
        random.nextBytes(salt);
        PBEKeySpec spec = new PBEKeySpec(password, salt, BACKUP_ITERATIONS, 256);
        byte[] keyBytes = null;
        try {
            keyBytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            SecretKeySpec key = new SecretKeySpec(keyBytes, "AES");
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] iv = cipher.getIV();
            cipher.updateAAD(BACKUP_MAGIC);
            cipher.updateAAD(intBytes(BACKUP_ITERATIONS));
            byte[] encrypted = cipher.doFinal(plaintext);

            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(bytes);
            out.write(BACKUP_MAGIC);
            out.writeInt(BACKUP_ITERATIONS);
            out.write(salt);
            out.write(iv);
            out.writeInt(encrypted.length);
            out.write(encrypted);
            out.flush();
            return bytes.toByteArray();
        } finally {
            spec.clearPassword();
            if (keyBytes != null) Arrays.fill(keyBytes, (byte) 0);
        }
    }

    public static byte[] decryptBackup(byte[] archive, char[] password) throws Exception {
        if (archive == null || archive.length < 8 + 4 + SALT_BYTES + IV_BYTES + 4 + 16 || archive.length > MAX_BACKUP_BYTES) {
            throw new IllegalArgumentException("备份文件长度异常");
        }
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(archive));
        byte[] magic = new byte[BACKUP_MAGIC.length];
        in.readFully(magic);
        if (!Arrays.equals(magic, BACKUP_MAGIC)) throw new IllegalArgumentException("不是消息留存 PRO 备份文件");
        int iterations = in.readInt();
        if (iterations < 100_000 || iterations > 1_000_000) throw new IllegalArgumentException("备份加密参数异常");
        byte[] salt = new byte[SALT_BYTES];
        byte[] iv = new byte[IV_BYTES];
        in.readFully(salt);
        in.readFully(iv);
        int length = in.readInt();
        if (length < 16 || length > MAX_BACKUP_BYTES || length != in.available()) throw new IllegalArgumentException("备份数据长度异常");
        byte[] encrypted = new byte[length];
        in.readFully(encrypted);

        PBEKeySpec spec = new PBEKeySpec(password, salt, iterations, 256);
        byte[] keyBytes = null;
        try {
            keyBytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(keyBytes, "AES"), new GCMParameterSpec(GCM_TAG_BITS, iv));
            cipher.updateAAD(BACKUP_MAGIC);
            cipher.updateAAD(intBytes(iterations));
            return cipher.doFinal(encrypted);
        } finally {
            spec.clearPassword();
            if (keyBytes != null) Arrays.fill(keyBytes, (byte) 0);
        }
    }

    private static byte[] intBytes(int value) {
        return new byte[]{
                (byte) ((value >>> 24) & 0xff),
                (byte) ((value >>> 16) & 0xff),
                (byte) ((value >>> 8) & 0xff),
                (byte) (value & 0xff)
        };
    }
}
