package com.nv.noticevault;

/** Pure classifier for the privilege identity exposed by Shizuku. */
public final class ShizukuPrivilege {
    public enum Mode { DISCONNECTED, ADB_SHELL, ROOT, OTHER }

    private ShizukuPrivilege() { }

    public static Mode classify(boolean binderAlive, int uid) {
        if (!binderAlive) return Mode.DISCONNECTED;
        if (uid == 2000) return Mode.ADB_SHELL;
        if (uid == 0) return Mode.ROOT;
        return Mode.OTHER;
    }
}
