package com.nv.noticevault;

import java.util.Locale;
import java.util.regex.Pattern;

/** Detects only explicit recall wording exposed by a notification. */
public final class RecallDetector {
    private static final Pattern RECALL = Pattern.compile(
            "(?:撤回了(?:一条)?(?:消息|信息)|recalled\\s+(?:a\\s+)?message|unsent\\s+(?:a\\s+)?message|message\\s+was\\s+recalled)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private RecallDetector() {}

    public static boolean isExplicitRecallNotice(String content) {
        if (content == null || content.trim().isEmpty()) return false;
        return RECALL.matcher(content.toLowerCase(Locale.ROOT)).find();
    }
}
