package com.nv.noticevault;

import android.app.Notification;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.OpenableColumns;
import android.text.TextUtils;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Parses only the fields Android exposes through the posted notification. */
public final class NotificationTextExtractor {
    private static final int MAX_PREVIEW_BYTES = 5 * 1024 * 1024;

    public static final class ParsedItem {
        public String sender = "";
        public String content = "";
        public long timestamp;
        public String messageType = "text";
        public String attachmentMime = "";
        public String attachmentName = "";
        public byte[] previewBytes;
    }

    private NotificationTextExtractor() {}

    public static List<ParsedItem> extract(Context context, Notification notification, long defaultTime) {
        ArrayList<ParsedItem> result = new ArrayList<>();
        if (notification == null || notification.extras == null) return result;
        Bundle extras = notification.extras;

        if (Build.VERSION.SDK_INT >= 26) {
            Parcelable[] historic = extras.getParcelableArray(Notification.EXTRA_HISTORIC_MESSAGES);
            appendMessageBundles(context, historic, defaultTime, result);
        }
        Parcelable[] messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES);
        appendMessageBundles(context, messages, defaultTime, result);

        if (!result.isEmpty()) {
            Bitmap picture = getPicture(extras);
            if (picture != null) {
                for (int i = result.size() - 1; i >= 0; i--) {
                    ParsedItem item = result.get(i);
                    if (item.previewBytes == null) {
                        item.previewBytes = bitmapToJpeg(picture);
                        item.attachmentMime = "image/jpeg";
                        item.messageType = "image";
                        item.attachmentName = "微信通知图片预览.jpg";
                        break;
                    }
                }
            }
            return result;
        }

        CharSequence content = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (TextUtils.isEmpty(content)) content = extras.getCharSequence(Notification.EXTRA_TEXT);
        if (!TextUtils.isEmpty(content)) {
            ParsedItem item = new ParsedItem();
            item.content = content.toString().trim();
            item.timestamp = defaultTime;
            Bitmap picture = getPicture(extras);
            if (picture != null) {
                item.previewBytes = bitmapToJpeg(picture);
                item.attachmentMime = "image/jpeg";
                item.messageType = "image";
                item.attachmentName = "微信通知图片预览.jpg";
            }
            result.add(item);
            return result;
        }

        CharSequence[] lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if (lines != null) {
            for (CharSequence line : lines) {
                if (TextUtils.isEmpty(line)) continue;
                ParsedItem item = new ParsedItem();
                item.content = line.toString().trim();
                item.timestamp = defaultTime;
                if (!item.content.isEmpty()) result.add(item);
            }
        }
        return result;
    }

    private static void appendMessageBundles(Context context, Parcelable[] bundles, long defaultTime, List<ParsedItem> out) {
        if (bundles == null) return;
        for (Parcelable parcelable : bundles) {
            if (!(parcelable instanceof Bundle)) continue;
            ParsedItem item = fromMessagingBundle(context, (Bundle) parcelable, defaultTime);
            if (item != null) out.add(item);
        }
    }

    private static ParsedItem fromMessagingBundle(Context context, Bundle message, long defaultTime) {
        CharSequence body = message.getCharSequence("text");
        Uri uri = null;
        String mime = message.getString("dataMimeType", "");
        try {
            Object value = message.get("dataUri");
            if (value instanceof Uri) uri = (Uri) value;
            else if (value instanceof String && !((String) value).isEmpty()) uri = Uri.parse((String) value);
        } catch (Exception ignored) {}
        if (TextUtils.isEmpty(body) && uri == null) return null;

        ParsedItem item = new ParsedItem();
        item.content = body == null ? "[非文字消息]" : body.toString().trim();
        long time = message.getLong("time", defaultTime);
        item.timestamp = time > 0 ? time : defaultTime;
        item.sender = readSender(message);
        item.attachmentMime = mime == null ? "" : mime;
        item.messageType = classifyMime(item.attachmentMime);
        if (uri != null && item.attachmentMime.toLowerCase(Locale.ROOT).startsWith("image/")) {
            byte[] bytes = readImageUri(context.getContentResolver(), uri);
            if (bytes != null) {
                item.previewBytes = bytes;
                item.attachmentName = queryDisplayName(context.getContentResolver(), uri);
                if (item.attachmentName.isEmpty()) item.attachmentName = "微信图片预览";
            }
        }
        return item;
    }

    private static String readSender(Bundle message) {
        Object senderValue = message.get("sender");
        if (senderValue instanceof CharSequence && !TextUtils.isEmpty((CharSequence) senderValue)) {
            return senderValue.toString();
        }
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                Object p = message.get("sender_person");
                if (p instanceof android.app.Person) {
                    CharSequence name = ((android.app.Person) p).getName();
                    if (!TextUtils.isEmpty(name)) return name.toString();
                }
            } catch (Exception ignored) {}
        }
        Bundle person = senderValue instanceof Bundle ? (Bundle) senderValue : null;
        if (person != null) {
            CharSequence name = person.getCharSequence("name");
            if (!TextUtils.isEmpty(name)) return name.toString();
        }
        return "";
    }

    private static Bitmap getPicture(Bundle extras) {
        try {
            Object value = extras.get(Notification.EXTRA_PICTURE);
            if (value instanceof Bitmap) return (Bitmap) value;
        } catch (Exception ignored) {}
        return null;
    }

    private static byte[] bitmapToJpeg(Bitmap bitmap) {
        if (bitmap == null) return null;
        try {
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            Bitmap scaled = bitmap;
            int maxDimension = 1600;
            if (Math.max(width, height) > maxDimension) {
                float scale = maxDimension / (float) Math.max(width, height);
                scaled = Bitmap.createScaledBitmap(bitmap, Math.max(1, Math.round(width * scale)), Math.max(1, Math.round(height * scale)), true);
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            scaled.compress(Bitmap.CompressFormat.JPEG, 86, out);
            byte[] bytes = out.toByteArray();
            if (scaled != bitmap) scaled.recycle();
            return bytes.length <= MAX_PREVIEW_BYTES ? bytes : null;
        } catch (Exception e) {
            return null;
        }
    }

    private static byte[] readImageUri(ContentResolver resolver, Uri uri) {
        try (InputStream in = resolver.openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) return null;
            byte[] buffer = new byte[8192];
            int total = 0;
            int n;
            while ((n = in.read(buffer)) >= 0) {
                total += n;
                if (total > MAX_PREVIEW_BYTES) return null;
                out.write(buffer, 0, n);
            }
            return out.size() == 0 ? null : out.toByteArray();
        } catch (Exception ignored) {
            // The content URI may not grant this app read access; metadata remains archived.
            return null;
        }
    }

    private static String queryDisplayName(ContentResolver resolver, Uri uri) {
        try (Cursor c = resolver.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {}
        return "";
    }

    private static String classifyMime(String mime) {
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (m.startsWith("image/")) return "image";
        if (m.startsWith("audio/")) return "voice";
        if (m.startsWith("video/")) return "video";
        if (!m.isEmpty()) return "file";
        return "text";
    }
}
