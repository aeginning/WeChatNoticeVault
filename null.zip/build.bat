@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle 8.13 is required. Install it or open this project with Android Studio.
  exit /b 2
)
gradle --version
if errorlevel 1 exit /b 1
gradle :app:clean :app:testDebugUnitTest :app:assembleDebug
if errorlevel 1 exit /b 1
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
